from cityu_pack.sub_func_pack.func_module import *

def test_add():
    assert add(1,2) == 3


