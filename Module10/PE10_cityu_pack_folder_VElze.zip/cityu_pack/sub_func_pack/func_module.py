def add(x,y):
    return x+y

def avg(x,y):
    return add(x,y)/2

def multiply(x,y):
    return x * y
